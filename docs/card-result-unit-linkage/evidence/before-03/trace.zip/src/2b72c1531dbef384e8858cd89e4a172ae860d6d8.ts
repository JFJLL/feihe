import { test, expect } from './evidence';
import type { APIRequestContext, Page } from '@playwright/test';
import { focusedProject, newFocusedCard, chooseFocused, focusedPreview } from './focused-helpers';

async function displayDataset(request: APIRequestContext, projectId: string, duplicates = false) {
  const values = duplicates ? [0.005, 0.005, 0.015, null] : [0.005, 0.015];
  const response = await request.post('/api/datasets', { data: {
    projectId, sourceId: 'card-display', name: '字段显示数据',
    columns: [{ key: 'completion', name: '完成率', type: 'number', numericUnit: 'percent', percentScale: 'fraction' }, { key: 'amount', name: '金额', type: 'number' }],
    rows: values.map((completion, i) => ({ completion, amount: (i + 1) * 10, status: '已完成', budget: 100, spent: 10, owner: '测试负责人' })),
  } });
  expect(response.status()).toBe(200);
  return (await response.json()).dataset;
}
async function value(page: Page, expected: string) {
  await expect(focusedPreview(page).locator('span').first()).toHaveText(expected);
}

for (const width of [1280, 390]) {
  test(`字段联动 A ${width}px：平均完成率切金额自动清理百分语义`, async ({ page, request }, info) => {
    await page.setViewportSize({ width, height: 844 });
    const projectId = await focusedProject(request, '字段联动');
    await displayDataset(request, projectId);
    await newFocusedCard(page, projectId, '字段切换平均');
    await chooseFocused(page, '指标计算方式', '数值平均 (Average)');
    await chooseFocused(page, '目标计算字段', '完成率');
    await value(page, '1.0%');
    await chooseFocused(page, '目标计算字段', '金额');
    await focusedPreview(page).scrollIntoViewIfNeeded();
    await page.screenshot({ path: info.outputPath('percent-to-amount-preview.png') });
    await value(page, '15');
    await expect(page.getByRole('combobox', { name: '显示格式', exact: true })).toContainText('普通数值');
    await expect(page.getByLabel('单位 (选填)', { exact: true })).toHaveValue('');
    await chooseFocused(page, '目标计算字段', '完成率');
    await value(page, '1.0%');
  });
  for (const aggregation of ['字段非空数', '唯一值计数 (去重计数)']) {
    test(`字段联动 B ${width}px：完成率${aggregation}显示计数2`, async ({ page, request }, info) => {
      await page.setViewportSize({ width, height: 844 });
      const projectId = await focusedProject(request, '计数联动');
      await displayDataset(request, projectId);
      await newFocusedCard(page, projectId, aggregation);
      await chooseFocused(page, '指标计算方式', aggregation);
      await chooseFocused(page, '目标计算字段', '完成率');
      await focusedPreview(page).scrollIntoViewIfNeeded();
      await page.screenshot({ path: info.outputPath('percent-field-count-preview.png') });
      await value(page, '2');
      await expect(page.getByRole('combobox', { name: '显示格式', exact: true })).toContainText('普通数值');
      await expect(page.getByLabel('单位 (选填)', { exact: true })).toHaveValue('');
    });
  }
}
