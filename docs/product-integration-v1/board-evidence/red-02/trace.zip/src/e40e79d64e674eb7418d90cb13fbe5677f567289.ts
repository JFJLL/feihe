import { test, expect } from './evidence';
import type { Page, APIRequestContext } from '@playwright/test';

const identity = { 'x-user-id': 'user-editor' };
const vendor = process.env.FEIHE_TEST_VENDOR_ORIGIN || 'http://127.0.0.1:5217';
async function choose(page: Page, label: string, option: string) {
  await page.getByRole('combobox', { name: label, exact: true }).click();
  await page.getByRole('option', { name: option, exact: true }).click();
}
async function fixture(request: APIRequestContext) {
  const created = await request.post('/api/projects', { headers: identity, data: { action: 'create', name: '共同周期与五类呈现' + Date.now(), templateId: 'general_workbench' } });
  expect(created.status()).toBe(200); const projectId = (await created.json()).id;
  const token = 'BoardViews-' + projectId;
  await request.post(vendor + '/__fixture/focused-rows', { data: { documentToken: token, rows: [
    ['日期', '渠道', '咨询人数', '成交人数'],
    ['2026-10-01 12:00:00', '门店', 100, 20],
    ['2026-10-01 23:59:59', '线上', 100, 10],
    ['2026-10-02 00:00:00', '门店', 100, 50],
    ['', '门店', 100, 90],
  ] } });
  const source = await request.post('/api/projects', { headers: identity, data: { action: 'save_source', projectId, name: '仅四列业务表', type: 'feishu_sheet', kind: 'general', spreadsheet: 'https://fixture.feishu.cn/sheets/' + token, sheetId: 'sheetA', mappingJson: '[]' } });
  expect(source.status()).toBe(200);
  expect((await request.post('/api/feishu/sync', { headers: identity, data: { projectId, sourceId: (await source.json()).id } })).status()).toBe(200);
  const state = await (await request.get('/api/datasets?projectId=' + projectId, { headers: identity })).json();
  const dataset = state.datasets[0]; expect(dataset.columns.find((c: { key: string }) => c.key === '日期').type).toBe('date');
  const config = { datasetId: dataset.id, aggregation: 'ratio', numField: '成交人数', denField: '咨询人数', dateField: '日期', missingPolicy: 'skip', ratioBasis: 'paired', format: 'percent', unit: '%' };
  const saved = await request.post('/api/metric-definitions', { headers: identity, data: { action: 'save', projectId, name: '成交率', config } });
  expect(saved.status()).toBe(200);
  return { projectId, metricId: (await saved.json()).id, config };
}

test('共享看板反例：同一指标能通过真实控件选择时间趋势', async ({ page, request }, info) => {
  await page.context().setExtraHTTPHeaders(identity); const { projectId } = await fixture(request);
  await page.goto('/projects/' + projectId); await page.getByRole('button', { name: '⚙ 自定义看板卡片', exact: true }).click();
  await page.getByRole('button', { name: '＋ 添加卡片', exact: true }).click();
  await page.getByRole('combobox', { name: '展示呈现形式', exact: true }).click();
  await page.screenshot({ path: info.outputPath('trend-option.png') });
  await page.getByRole('option', { name: '时间趋势', exact: true }).click();
  await expect(page.getByRole('dialog')).toContainText('按项目时区');
});
test('共享看板反例：项目周期是真实日期控件且包含完整结束日', async ({ page, request }, info) => {
  await page.context().setExtraHTTPHeaders(identity); const { projectId, metricId } = await fixture(request);
  expect((await request.post('/api/dashboards', { headers: identity, data: { projectId, cards: [{ title: '团队成交率', type: 'metric_card', config: { metricId } }] } })).status()).toBe(200);
  await page.goto('/projects/' + projectId);
  await expect(page.getByRole('article', { name: '团队成交率', exact: true })).toContainText('42.5%');
  await page.screenshot({ path: info.outputPath('missing-project-period.png') });
  await page.getByLabel('项目开始日期', { exact: true }).fill('2026-10-01');
  await page.getByLabel('项目结束日期', { exact: true }).fill('2026-10-01');
  await expect(page.getByRole('article', { name: '团队成交率', exact: true })).toContainText('15.0%');
  await expect(page.getByRole('article', { name: '团队成交率', exact: true })).toContainText('成对有效 2 行');
});
