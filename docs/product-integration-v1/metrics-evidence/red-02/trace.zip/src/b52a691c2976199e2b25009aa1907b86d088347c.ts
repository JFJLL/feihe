import { test, expect } from './evidence';
import type { Page, APIRequestContext } from '@playwright/test';
const identity = { 'x-user-id': 'user-editor' };
const vendor = process.env.FEIHE_TEST_VENDOR_ORIGIN || 'http://127.0.0.1:5217';
async function choose(page: Page, label: string, option: string) {
  await page.getByRole('combobox', { name: label, exact: true }).click();
  await page.getByRole('option', { name: option, exact: true }).click();
}
async function fixture(request: APIRequestContext) {
  const created = await request.post('/api/projects', { headers: identity, data: { action: 'create', name: '共享指标' + Date.now(), templateId: 'general_workbench' } });
  expect(created.status()).toBe(200); const id = (await created.json()).id;
  const token = 'SharedMetric-' + id;
  await request.post(vendor + '/__fixture/focused-rows', { data: { documentToken: token, rows: [['日期', '渠道', '咨询人数', '成交人数'], ['2026-10-01', '门店', '', 10], ['2026-10-02', '线上', 100, ''], ['2026-10-03', '门店', 100, 20]] } });
  const source = await request.post('/api/projects', { headers: identity, data: { action: 'save_source', projectId: id, name: '咨询成交原表', type: 'feishu_sheet', kind: 'general', spreadsheet: 'https://fixture.feishu.cn/sheets/' + token, sheetId: 'sheetA', mappingJson: '[]' } });
  expect(source.status()).toBe(200);
  expect((await request.post('/api/feishu/sync', { headers: identity, data: { projectId: id, sourceId: (await source.json()).id } })).status()).toBe(200);
  return id as string;
}
for (const width of [1280, 390]) {
  test(`共享指标 ${width}px：定义一次，两张卡引用，版本修改影响全部卡且历史口径可计算`, async ({ page, request }, info) => {
    await page.setViewportSize({ width, height: 900 }); await page.context().setExtraHTTPHeaders(identity);
    const projectId = await fixture(request);
    await page.goto('/projects/' + projectId + '/metrics');
    await expect(page.getByRole('heading', { name: '项目指标', exact: true })).toBeVisible();
    await page.getByRole('button', { name: '新建指标', exact: true }).click();
    await page.getByRole('textbox', { name: '指标名称', exact: true }).fill('成交率');
    await choose(page, '指标计算方式', '比率转化 (分子 / 分母 加权比率)');
    await choose(page, '分子字段', '成交人数'); await choose(page, '分母字段', '咨询人数');
    await expect(page.getByText('🔍 全量指标实时试算预览：').locator('..')).toContainText('20.0%');
    await page.getByRole('button', { name: '保存指标', exact: true }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    const metricRow = page.getByRole('row').filter({ has: page.getByRole('cell', { name: '成交率', exact: true }) });
    await expect(metricRow).toContainText('v1'); await expect(metricRow).toContainText('项目私有');
    const definitions = await (await request.get('/api/metric-definitions?projectId=' + projectId, { headers: identity })).json();
    expect(definitions.metrics).toHaveLength(1); const metricId = definitions.metrics[0].id;
    await metricRow.getByRole('button', { name: '加入看板', exact: true }).click();
    await expect(page.getByRole('dialog', { name: '添加共享指标卡片', exact: true })).toBeVisible();
    await page.getByRole('textbox', { name: '卡片标题', exact: true }).fill('成交率总盘');
    await page.getByRole('button', { name: '加入草稿', exact: true }).click();
    await page.getByRole('button', { name: '＋ 添加卡片', exact: true }).click();
    await choose(page, '选择指标', '成交率 · v1 · 咨询成交原表');
    await choose(page, '展示呈现形式', '分组对比');
    await choose(page, '分组字段', '渠道');
    await page.getByRole('textbox', { name: '卡片标题', exact: true }).fill('成交率渠道');
    await page.getByRole('button', { name: '加入草稿', exact: true }).click();
    const saved = page.waitForResponse(r => r.url().endsWith('/api/dashboards') && r.request().method() === 'POST');
    await page.getByRole('button', { name: '✓ 保存并发布看板', exact: true }).click(); expect((await saved).status()).toBe(200);
    await page.reload();
    const whole = page.getByRole('article', { name: '成交率总盘', exact: true }), grouped = page.getByRole('article', { name: '成交率渠道', exact: true });
    await expect(whole).toContainText('20.0%'); await expect(grouped).toContainText('20.0%');
    const stored = await (await request.get('/api/dashboards?projectId=' + projectId, { headers: identity })).json();
    expect(stored.cards).toHaveLength(2);
    for (const card of stored.cards) { const config = JSON.parse(card.configJson); expect(config.metricId).toBe(metricId); expect(config.metricVersionPolicy).toBe('latest'); expect(config.numField).toBeUndefined(); expect(config.aggregation).toBeUndefined(); }
    await page.goto('/projects/' + projectId + '/metrics');
    await metricRow.getByRole('button', { name: '编辑指标', exact: true }).click();
    await expect(page.getByRole('dialog')).toContainText('影响 2 张看板卡片');
    await choose(page, '比率样本口径', '独立汇总（分别求和）');
    await page.getByRole('button', { name: '保存指标', exact: true }).click();
    await expect(metricRow).toContainText('v2');
    await page.goto('/projects/' + projectId);
    await expect(whole).toContainText('15.0%'); await expect(grouped).toContainText('15.0%');
    await expect(whole).toContainText('指标 v2'); await expect(grouped).toContainText('指标 v2');
    await expect(grouped.getByTestId('metric-group').filter({ hasText: '门店' })).toContainText('30.0%');
    await page.screenshot({ path: info.outputPath('shared-definition-two-views.png'), fullPage: true });
    const historical = await request.post('/api/metrics', { headers: identity, data: { projectId, card: { metricId, metricVersionPolicy: 'pinned', metricVersion: 1, type: 'metric_card' } } });
    expect(historical.status()).toBe(200); expect((await historical.json()).metric.formattedValue).toBe('20.0%');
    const after = await (await request.get('/api/metric-definitions?projectId=' + projectId, { headers: identity })).json();
    expect(after.metrics[0].versions).toHaveLength(2); expect(after.metrics[0].version).toBe(2);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  });
}
