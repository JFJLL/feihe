import { test, expect } from './evidence';
import { connectProjectTable, publishRecommendedBoard, projectIdentity, consultationRows } from './product-journey';

test('报告断链反例：四列原表看板发布后，经页面进入同口径项目报告', async ({ page, request }, info) => {
  await connectProjectTable(page, request, 'general_workbench', consultationRows);
  await publishRecommendedBoard(page);
  await expect(page.getByRole('article', { name: '咨询人数合计', exact: true })).toContainText('300');
  await page.screenshot({ path: info.outputPath('published-board-without-report-path.png'), fullPage: true });
  await page.getByRole('link', { name: '查看项目报告', exact: true }).click();
  await expect(page.getByRole('heading', { name: '项目报告', exact: true })).toBeVisible();
});
test('报告取数反例：已有生成接口消费真实共享咨询指标，而非空社媒记录', async ({ page, request }, info) => {
  const { projectId } = await connectProjectTable(page, request, 'general_workbench', consultationRows);
  await publishRecommendedBoard(page);
  const generated = await request.post('/api/agent', { headers: projectIdentity, data: { projectId, prompt: '查看咨询人数和成交率' } });
  expect(generated.status()).toBe(200); const report = await generated.json();
  await info.attach('报告真实响应', { body: JSON.stringify(report, null, 2), contentType: 'application/json' });
  expect(report.spec.kpis.find((k: { label: string }) => k.label === '咨询人数合计')?.value).toBe('300');
  expect(report.spec.metrics.some((m: { metricId: string }) => m.metricId && m.title === '成交率')).toBeTruthy();
});
