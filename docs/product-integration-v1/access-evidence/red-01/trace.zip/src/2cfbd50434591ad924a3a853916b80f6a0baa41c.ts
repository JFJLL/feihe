import { test, expect } from './evidence';
import { connectProjectTable, publishRecommendedBoard, projectIdentity, consultationRows } from './product-journey';

test('页面权限反例：原身份真实缓存后，无成员的新身份不能挂载项目私有页面', async ({ page, request }, info) => {
  const { projectId } = await connectProjectTable(page, request, 'general_workbench', consultationRows);
  await publishRecommendedBoard(page);
  const privateName = '隔离访问项目' + projectId;
  expect((await request.post('/api/projects', { headers: projectIdentity, data: { action: 'update', projectId, name: privateName } })).status()).toBe(200);
  await page.reload(); await expect(page.getByRole('heading', { name: privateName, exact: true })).toBeVisible();
  await page.waitForFunction(() => Object.keys(sessionStorage).some(key => key.includes('project-data:')));
  await page.context().setExtraHTTPHeaders({ 'x-user-id': 'user-viewer' });
  expect((await request.get('/api/datasets?projectId=' + projectId, { headers: { 'x-user-id': 'user-viewer' } })).status()).toBe(403);
  await page.goto('/projects/' + projectId + '/data');
  await page.screenshot({ path: info.outputPath('cached-project-unauthorized-entry.png'), fullPage: true });
  await expect(page.getByRole('heading', { name: '无权访问此项目', exact: true })).toBeVisible();
  await expect(page.getByText(privateName, { exact: true })).toHaveCount(0);
  await expect(page.getByRole('navigation', { name: '项目模块', exact: true })).toHaveCount(0);
});
test('撤权反例：负责人交接并移除创建者后，报告、导出和页面都必须拒绝原创建者', async ({ page, request }, info) => {
  const { projectId } = await connectProjectTable(page, request, 'general_workbench', consultationRows); await publishRecommendedBoard(page);
  const generated = await request.post('/api/reports', { headers: projectIdentity, data: { projectId } }); expect(generated.status()).toBe(200); const reportId = (await generated.json()).reportId;
  expect((await request.post('/api/projects', { headers: projectIdentity, data: { action: 'add_member', projectId, userId: 'user-project-manager', role: 'project_admin' } })).status()).toBe(200);
  expect((await request.post('/api/projects', { headers: projectIdentity, data: { action: 'update', projectId, ownerId: 'user-project-manager' } })).status()).toBe(200);
  const manager = { 'x-user-id': 'user-project-manager' };
  expect((await request.post('/api/projects', { headers: manager, data: { action: 'remove_member', projectId, userId: 'user-editor' } })).status()).toBe(200);
  const denied = await request.get('/api/reports?projectId=' + projectId, { headers: projectIdentity });
  await info.attach('创建者撤权后的真实报告响应', { body: JSON.stringify({ status: denied.status(), body: await denied.json() }), contentType: 'application/json' });
  expect(denied.status()).toBe(403);
  expect((await request.get('/api/report-html?projectId=' + projectId + '&id=' + reportId, { headers: projectIdentity })).status()).toBe(403);
  await page.goto('/projects/' + projectId + '/reports'); await expect(page.getByRole('heading', { name: '无权访问此项目', exact: true })).toBeVisible();
  await page.screenshot({ path: info.outputPath('revoked-creator-denied.png') });
});
