import { test, expect } from './evidence';
test('启萃组件反例：真实页面有权用户能打开既有复杂图表的团队布局编辑入口', async ({ page }, info) => {
  await page.context().setExtraHTTPHeaders({ 'x-user-id': 'user-admin' }); await page.goto('/projects/qicui');
  await expect(page.getByRole('heading', { name: '内容效果深度分析', exact: true })).toBeVisible();
  await page.screenshot({ path: info.outputPath('qicui-components-before.png'), fullPage: true });
  await page.getByRole('button', { name: '配置业务组件布局', exact: true }).click();
  await expect(page.getByRole('dialog', { name: '团队业务组件布局', exact: true })).toBeVisible();
});
