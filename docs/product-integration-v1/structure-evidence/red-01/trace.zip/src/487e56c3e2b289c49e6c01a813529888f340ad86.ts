import { test, expect } from './evidence';
import { connectProjectTable, publishRecommendedBoard, projectIdentity, consultationRows } from './product-journey';

test('结构复用反例：普通负责人在新建表单选择已有授权项目，看到不复制来源和真实目标的确认', async ({ page, request }, info) => {
  const { projectId } = await connectProjectTable(page, request, 'general_workbench', consultationRows); await publishRecommendedBoard(page);
  await page.goto('/'); await page.getByRole('button', { name: '＋ 新建项目', exact: true }).click();
  await page.getByRole('combobox', { name: '复用项目结构', exact: true }).click();
  await expect(page.getByRole('option').filter({ hasText: '独立部门报告' })).toBeVisible();
  await info.attach('结构来源项目', { body: JSON.stringify({ projectId, actor: projectIdentity }), contentType: 'application/json' });
});
