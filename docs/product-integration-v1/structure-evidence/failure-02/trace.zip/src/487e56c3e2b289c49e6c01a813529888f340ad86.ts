import { test, expect } from './evidence';
import { connectProjectTable, connectExistingProjectTable, publishRecommendedBoard, projectIdentity, consultationRows, dismissProjectNotifications } from './product-journey';
import type { Page, APIRequestContext } from '@playwright/test';

test('结构复用反例：普通负责人在新建表单选择已有授权项目，看到不复制来源和真实目标的确认', async ({ page, request }, info) => {
  const { projectId } = await connectProjectTable(page, request, 'general_workbench', consultationRows); await publishRecommendedBoard(page);
  await page.goto('/'); await page.getByRole('button', { name: '＋ 新建项目', exact: true }).click();
  await page.getByRole('combobox', { name: '复用项目结构', exact: true }).click();
  await expect(page.getByRole('option').filter({ hasText: '独立部门报告' })).toBeVisible(); await page.getByRole('option').filter({ hasText: '独立部门报告' }).click();
  await expect(page.getByText('客户资料、成员、来源链接与授权、私有记录、供应商、历史报告、实际目标和日期范围都不会复制。', { exact: false })).toBeVisible();
  await page.getByRole('textbox', { name: '项目名称', exact: true }).fill('复用结构新项目'); await expect(page.getByRole('button', { name: '创建项目并开启向导', exact: true })).toBeDisabled();
  await info.attach('结构来源项目', { body: JSON.stringify({ projectId, actor: projectIdentity }), contentType: 'application/json' });
});
async function createFromStructure(page: Page, request: APIRequestContext, sourceId: string) {
  const source = (await (await request.get('/api/projects?projectId=' + sourceId, { headers: projectIdentity })).json()).project;
  await page.goto('/'); await page.getByRole('button', { name: '＋ 新建项目', exact: true }).click();
  await page.getByRole('textbox', { name: '项目名称', exact: true }).fill('第二客户独立结构' + Date.now());
  await page.getByRole('combobox', { name: '复用项目结构', exact: true }).click(); await page.getByRole('option', { name: source.name + ' · ' + source.templateName, exact: true }).click();
  const acknowledge = page.getByRole('checkbox', { name: '我确认仅复用结构，并重新接入本项目来源及设置目标', exact: true }); await expect(acknowledge).toBeVisible(); await acknowledge.check();
  const created = page.waitForResponse(response => response.url().endsWith('/api/projects') && response.request().method() === 'POST'); await page.getByRole('button', { name: '创建项目并开启向导', exact: true }).click(); expect((await created).status()).toBe(200); const targetId = (await (await created).json()).id;
  await expect(page).toHaveURL(new RegExp('/projects/' + targetId + '$')); await expect(page.getByRole('heading', { name: /下一步：接入自己的业务表/ })).toBeVisible();
  const empty = await (await request.get('/api/datasets?projectId=' + targetId, { headers: projectIdentity })).json(); expect(empty.datasets).toHaveLength(0);
  const workspace = await (await request.get('/api/projects', { headers: projectIdentity })).json(); expect(workspace.sources.filter((source: { projectId: string }) => source.projectId === targetId)).toHaveLength(0);
  return targetId;
}
async function mapField(page: Page, sourceName: string, targetName: string) {
  const select = page.getByRole('combobox', { name: '来源1 ' + sourceName + '对应字段', exact: true }); await select.click(); await page.getByRole('option', { name: targetName, exact: true }).click();
}
for (const width of [1280, 390]) {
  test(`授权结构复用 ${width}px：新项目→自己的新表与不同字段→目标确认→试算→草稿→发布刷新→报告及只读`, async ({ page, request }, info) => {
    await page.setViewportSize({ width, height: 900 });
    const source = await connectProjectTable(page, request, 'general_workbench', consultationRows); await publishRecommendedBoard(page);
    const board = await (await request.get('/api/dashboards?projectId=' + source.projectId, { headers: projectIdentity })).json(); const reference = JSON.parse(board.cards.find((card: { title: string }) => card.title === '咨询人数合计').configJson).metricId;
    const sourceCards = board.cards.map((card: { id: string; title: string; type: string; configJson: string }) => ({ id: card.id, title: card.title, type: card.type, config: JSON.parse(card.configJson) }));
    const added = await request.post('/api/dashboards', { headers: projectIdentity, data: { projectId: source.projectId, version: board.dashboards[0].version, cards: [...sourceCards, { title: '本项目咨询目标', type: 'progress_card', config: { metricId: reference, target: 600, targetMetricVersion: 1 } }] } }); expect(added.status()).toBe(200);
    const targetId = await createFromStructure(page, request, source.projectId);
    await connectExistingProjectTable(page, request, targetId, [['业务日期', '业务渠道', '问询量', '签约量'], ['2026-11-01', '线下', 400, 80], ['2026-11-02', '网站', 200, 10]]);
    await page.getByRole('button', { name: '确认复用指标与看板', exact: true }).click(); const dialog = page.getByRole('dialog', { name: '绑定本项目来源并确认复用看板', exact: true });
    for (const [from, to] of [['日期', '业务日期'], ['渠道', '业务渠道'], ['咨询人数', '问询量'], ['成交人数', '签约量']]) await mapField(page, from, to);
    await expect(dialog.getByText('本项目试算：600', { exact: true })).toBeVisible(); const target = dialog.getByRole('spinbutton', { name: '本项目咨询目标本项目目标', exact: true }); await expect(target).toHaveValue('');
    await expect(dialog.getByRole('button', { name: '确认复用并进入看板草稿', exact: true })).toBeDisabled(); await target.focus(); await target.pressSequentially('1200'); await expect(target).toBeFocused(); await expect(target).toHaveValue('1200');
    await expect(dialog.getByRole('button', { name: '确认复用并进入看板草稿', exact: true })).toBeEnabled(); await page.screenshot({ path: info.outputPath('own-fields-goal-and-real-preview.png'), fullPage: true });
    const applied = page.waitForResponse(response => response.url().endsWith('/api/project-structure') && response.request().method() === 'POST'); await dialog.getByRole('button', { name: '确认复用并进入看板草稿', exact: true }).click(); expect((await applied).status()).toBe(200);
    await page.getByRole('button', { name: '✓ 保存并发布看板', exact: true }).click(); await expect(page.getByRole('button', { name: '✓ 保存并发布看板', exact: true })).toHaveCount(0); await page.reload(); await dismissProjectNotifications(page);
    const current = await (await request.get('/api/dashboards?projectId=' + targetId, { headers: projectIdentity })).json(); expect(current.cards).toHaveLength(sourceCards.length + 1); const configs = current.cards.map((card: { configJson: string }) => JSON.parse(card.configJson));
    expect(configs.find((card: { title: string }) => card.title === '本项目咨询目标').target).toBe(1200); expect(configs.every((card: { metricId: string }) => card.metricId.startsWith(targetId + ':structure:'))).toBeTruthy(); expect(configs.every((card: { from?: string; to?: string }) => !card.from && !card.to)).toBeTruthy();
    const amount = page.locator('.configured-board .dashboard-card').filter({ has: page.locator('h4', { hasText: /^咨询人数合计$/ }) }); await expect(amount).toContainText('600');
    await page.screenshot({ path: info.outputPath('new-project-published-own-results.png'), fullPage: true });
    const generated = await request.post('/api/reports', { headers: projectIdentity, data: { projectId: targetId } }); expect(generated.status()).toBe(200);
    await request.post('/api/projects', { headers: projectIdentity, data: { action: 'add_member', projectId: targetId, userId: 'user-viewer', role: 'viewer' } }); await page.context().setExtraHTTPHeaders({ 'x-user-id': 'user-viewer' }); await page.goto('/projects/' + targetId + '/reports');
    await expect(page.getByRole('article', { name: '咨询人数合计报告结果', exact: true })).toContainText('600'); await expect(page.getByRole('button', { name: '生成并保存报告', exact: true })).toHaveCount(0); await page.screenshot({ path: info.outputPath('reused-project-viewer-report.png'), fullPage: true });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBeTruthy();
    const original = await (await request.get('/api/dashboards?projectId=' + source.projectId, { headers: projectIdentity })).json(); expect(JSON.parse(original.cards.find((card: { title: string }) => card.title === '本项目咨询目标').configJson).target).toBe(600);
  });
}
