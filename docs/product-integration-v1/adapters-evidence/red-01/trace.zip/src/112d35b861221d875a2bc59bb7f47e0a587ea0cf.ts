import { test, expect } from './evidence';
import type { Page, APIRequestContext } from '@playwright/test';
const identity = { 'x-user-id': 'user-editor' };
const vendor = process.env.FEIHE_TEST_VENDOR_ORIGIN || 'http://127.0.0.1:5217';
async function connect(page: Page, request: APIRequestContext, templateId: string, rows: unknown[][]) {
  await page.context().setExtraHTTPHeaders(identity);
  const created = await request.post('/api/projects', { headers: identity, data: { action: 'create', name: '字段驱动接入' + Date.now(), templateId } });
  expect(created.status()).toBe(200); const projectId = (await created.json()).id;
  const token = 'Adapter-' + projectId;
  expect((await request.post(vendor + '/__fixture/focused-rows', { data: { documentToken: token, rows } })).status()).toBe(200);
  await page.goto('/projects/' + projectId + '/data');
  await page.getByRole('button', { name: /接入飞书数据源/ }).click();
  await page.getByRole('textbox', { name: '飞书表格链接', exact: true }).fill('https://fixture.feishu.cn/sheets/' + token);
  await page.getByRole('button', { name: '智能检测工作表 ↗' }).click();
  await expect(page.getByRole('combobox', { name: '目标工作表', exact: true })).toContainText('补修数据');
  const synced = page.waitForResponse(r => r.url().endsWith('/api/feishu/sync') && r.request().method() === 'POST');
  await page.getByRole('button', { name: '✓ 保存并首次同步', exact: true }).click(); expect((await synced).status()).toBe(200);
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('tab', { name: '数据集', exact: true }).click();
  await expect(page.getByRole('table', { name: '业务数据明细', exact: true })).toContainText(String(rows[1][2]));
  return { projectId, token };
}
test('字段推荐反例：陌生四列表接入后可以经真实控件确认适用的指标和看板', async ({ page, request }, info) => {
  const { projectId } = await connect(page, request, 'general_workbench', [['日期', '渠道', '咨询人数', '成交人数'], ['2026-10-01', '门店', 100, 20], ['2026-10-02', '线上', 200, 10]]);
  await page.screenshot({ path: info.outputPath('no-field-recommendation.png'), fullPage: true });
  await page.getByRole('button', { name: '推荐指标与看板', exact: true }).click();
  await expect(page.getByRole('dialog')).toContainText('成交率');
  await expect(page.getByRole('dialog')).not.toContainText('预算执行率');
  await expect(page.getByRole('dialog')).not.toContainText('任务完成率');
  expect((await (await request.get('/api/datasets?projectId=' + projectId, { headers: identity })).json()).datasets[0].columns.map((c: { key: string }) => c.key)).toEqual(['日期', '渠道', '咨询人数', '成交人数']);
});
test('投放断链反例：五列新来源真实入库后专属投放消耗显示本项目300', async ({ page, request }, info) => {
  const { projectId } = await connect(page, request, 'ad_performance', [['日期', '渠道', '花费', '曝光', '点击'], ['2026-10-01', '新客户门店', 100, 1000, 10], ['2026-10-02', '新客户线上', 200, 3000, 60]]);
  await page.goto('/projects/' + projectId);
  const overview = page.getByTestId('ad-performance-overview');
  await expect(overview).toBeVisible(); await page.screenshot({ path: info.outputPath('imported-ad-dataset-disconnected.png'), fullPage: true });
  await expect(overview.locator('.ops-metric-card').filter({ hasText: '广告消耗' })).toContainText('300');
});
